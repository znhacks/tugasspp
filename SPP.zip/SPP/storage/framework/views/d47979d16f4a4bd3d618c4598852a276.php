

<?php $__env->startSection('content'); ?>
<h3>Tambah Kelas</h3>

<form action="<?php echo e(url('admin/kelas')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label>Kelas</label>
        <input type="text" name="kelas" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Wali Kelas</label>
        <input type="text" name="walikelas" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Keterangan</label>
        <textarea name="keterangan" class="form-control"></textarea>
    </div>

    <button class="btn btn-primary">Simpan</button>
    <a href="<?php echo e(url('admin/kelas')); ?>" class="btn btn-secondary">Kembali</a>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/kelas/create.blade.php ENDPATH**/ ?>