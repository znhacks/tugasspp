

<?php $__env->startSection('content'); ?>
<h3>Data Siswa</h3>

<a href="<?php echo e(url('admin/siswa/create')); ?>" class="btn btn-primary mb-3">Tambah Siswa</a>

<table class="table table-bordered">
    <tr>
        <th>Foto</th>
        <th>NIS</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Aksi</th>
    </tr>

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td style="width:100px">
            <?php if($s->foto): ?>
                <a href="#" class="thumb" data-src="<?php echo e(asset('storage/' . $s->foto)); ?>" title="Klik untuk memperbesar">
                    <img src="<?php echo e(asset('storage/' . $s->foto)); ?>" alt="foto" class="img-thumb img-thumbnail">
                </a>
            <?php else: ?>
                <img src="<?php echo e(asset('images/placeholder-80.png')); ?>" alt="no photo" class="img-thumb img-thumbnail">
            <?php endif; ?>
        </td>
        <td><?php echo e($s->nis); ?></td>
        <td><?php echo e($s->nama); ?></td>
        <td><?php echo e($s->kelas->kelas ?? '-'); ?></td>
        <td>
            <a href="<?php echo e(url('admin/siswa/' . $s->id . '/edit')); ?>" class="btn btn-warning btn-sm">Edit</a>
            <form action="<?php echo e(url('admin/siswa/' . $s->id)); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="btn btn-danger btn-sm">Hapus</button>
            </form>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<!-- Image modal (Bootstrap) -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-transparent border-0">
      <div class="modal-body p-0 text-center">
        <button type="button" class="btn-close position-absolute end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <img id="modalImage" src="" alt="preview" style="max-width:100%; max-height:80vh; object-fit:contain;">
      </div>
    </div>
  </div>
</div>

<style>
.img-thumb { width:80px; height:80px; object-fit:cover; cursor:pointer; }
</style>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const bsModal = new bootstrap.Modal(modalEl);

    document.querySelectorAll('.thumb').forEach(function(el){
        el.addEventListener('click', function(e){
            e.preventDefault();
            const src = this.getAttribute('data-src');
            modalImage.src = src;
            bsModal.show();
        });
    });

    modalEl.addEventListener('hidden.bs.modal', function () {
        modalImage.src = '';
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/siswa/index.blade.php ENDPATH**/ ?>