

<?php $__env->startSection('content'); ?>
<h3>Edit Pelanggaran</h3>

<form action="<?php echo e(url('admin/pelanggaran/' . $pelanggaran->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <label>Foto Bukti</label><br>
    <?php if($pelanggaran->foto): ?>
        <img src="<?php echo e(asset('storage/' . $pelanggaran->foto)); ?>" width="120" class="mb-3">
    <?php endif; ?>
    <input type="file" name="foto" class="form-control mb-2">

    <label>Tanggal</label>
    <input type="date" name="tanggal" value="<?php echo e($pelanggaran->tanggal); ?>" class="form-control mb-2">

    <label>Siswa</label>
    <select name="siswa_id" class="form-control mb-2">
        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id); ?>" <?php echo e($s->id==$pelanggaran->siswa_id?'selected':''); ?>>
                <?php echo e($s->nama); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Jenis Pelanggaran</label>
    <select name="jenis_id" class="form-control mb-2">
        <?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($j->id); ?>" <?php echo e($j->id==$pelanggaran->jenis_id?'selected':''); ?>>
                <?php echo e($j->jenis); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <label>Petugas</label>
    <select name="user_id" class="form-control mb-2">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($u->id); ?>" <?php echo e($u->id==$pelanggaran->user_id?'selected':''); ?>>
                <?php echo e($u->nama); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button class="btn btn-primary mt-3">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/pelanggaran/edit.blade.php ENDPATH**/ ?>