

<?php $__env->startSection('content'); ?>
<h3>Edit Kelas</h3>

<form action="<?php echo e(url('admin/kelas/' . $kelas->id)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <label>Nama Kelas</label>
    <input type="text" name="kelas" value="<?php echo e($kelas->kelas); ?>" class="form-control mb-2">

    <label>Wali Kelas</label>
    <input type="text" name="walikelas" value="<?php echo e($kelas->walikelas); ?>" class="form-control mb-2">

    <label>Keterangan</label>
    <input type="text" name="keterangan" value="<?php echo e($kelas->keterangan); ?>" class="form-control mb-2">

    <button class="btn btn-primary mt-3">Update</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/kelas/edit.blade.php ENDPATH**/ ?>