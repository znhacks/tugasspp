<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin BK - <?php echo $__env->yieldContent('title'); ?></title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background: #f4f6f9;
        }
        .sidebar {
            width: 230px;
            height: 100vh;
            background: #343a40;
            position: fixed;
            padding-top: 20px;
        }
        .sidebar a {
            color: #fff;
            display: block;
            padding: 12px 20px;
            text-decoration: none;
        }
        .sidebar a:hover {
            background: #495057;
        }
        .content-area {
            margin-left: 230px;
            padding: 30px;
        }
    </style>
</head>

<body>

    <div class="sidebar">

        <h4 class="text-center text-white mb-4">ADMIN PANEL</h4>

        <a href="<?php echo e(url('/admin')); ?>">Dashboard</a>
        <a href="<?php echo e(url('/admin/siswa')); ?>">Data Siswa</a>
        <a href="<?php echo e(url('/admin/jenis')); ?>">Jenis Pelanggaran</a>
        <a href="<?php echo e(url('/admin/pelanggaran')); ?>">Data Pelanggaran</a>
        <a href="<?php echo e(url('/admin/kelas')); ?>">Data Kelas</a>

        <hr class="text-white">

        <!-- HOME BUTTON (BENAR) -->
        <a href="<?php echo e(url('/')); ?>" class="btn btn-light text-dark w-100 mb-2">
            Home
        </a>

        <!-- LOGOUT BUTTON -->
        <form action="<?php echo e(url('/admin/logout')); ?>" method="POST" class="text-center">
            <?php echo csrf_field(); ?>
            <button class="btn btn-danger w-100">Logout</button>
        </form>

    </div>

    <div class="content-area">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>
<?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/layouts/admin.blade.php ENDPATH**/ ?>