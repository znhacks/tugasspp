

<?php $__env->startSection('content'); ?>
<h3>Tambah Siswa</h3>

<form action="<?php echo e(url('admin/siswa')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <label>NIS</label>
    <input type="text" name="nis" class="form-control mb-2">

    <label>Nama</label>
    <input type="text" name="nama" class="form-control mb-2">

    <label>Jenis Kelamin</label>
    <select name="kelamin" class="form-control mb-2">
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
    </select>

    <label>Agama</label>
    <input type="text" name="agama" class="form-control mb-2">

    <label>Alamat</label>
    <textarea name="alamat" class="form-control mb-2"></textarea>

    <label>Foto</label>
    <input type="file" name="foto" class="form-control mb-2">

    <label>Kelas</label>
    <select name="kelas_id" class="form-control mb-2">
        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k->id); ?>"><?php echo e($k->kelas); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    <button class="btn btn-primary mt-3">Simpan</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ZenVision\SPP\SPP\resources\views/admin/siswa/create.blade.php ENDPATH**/ ?>