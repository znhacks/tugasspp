@extends('admin.layouts.admin')

@section('content')
<h3>Edit Pelanggaran</h3>

<form action="{{ url('admin/pelanggaran/' . $pelanggaran->id) }}" method="POST" enctype="multipart/form-data">
    @csrf @method('PUT')

    <label>Foto Bukti</label><br>
    @if($pelanggaran->foto)
        <img src="{{ asset('storage/' . $pelanggaran->foto) }}" width="120" class="mb-3">
    @endif
    <input type="file" name="foto" class="form-control mb-2">

    <label>Tanggal</label>
    <input type="date" name="tanggal" value="{{ $pelanggaran->tanggal }}" class="form-control mb-2">

    <label>Siswa</label>
    <select name="siswa_id" class="form-control mb-2">
        @foreach ($siswa as $s)
            <option value="{{ $s->id }}" {{ $s->id==$pelanggaran->siswa_id?'selected':'' }}>
                {{ $s->nama }}
            </option>
        @endforeach
    </select>

    <label>Jenis Pelanggaran</label>
    <select name="jenis_id" class="form-control mb-2">
        @foreach ($jenis as $j)
            <option value="{{ $j->id }}" {{ $j->id==$pelanggaran->jenis_id?'selected':'' }}>
                {{ $j->jenis }}
            </option>
        @endforeach
    </select>

    <label>Petugas</label>
    <select name="user_id" class="form-control mb-2">
        @foreach ($user as $u)
            <option value="{{ $u->id }}" {{ $u->id==$pelanggaran->user_id?'selected':'' }}>
                {{ $u->nama }}
            </option>
        @endforeach
    </select>

    <button class="btn btn-primary mt-3">Update</button>
</form>
@endsection
