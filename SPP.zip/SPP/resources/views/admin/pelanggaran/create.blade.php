@extends('admin.layouts.admin')

@section('content')
<h3>Tambah Pelanggaran</h3>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif

@if($errors->any())
    <div class="alert alert-danger">
        <ul class="mb-0">
            @foreach ($errors->all() as $err)
                <li>{{ $err }}</li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ url('admin/pelanggaran') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <label>Foto Bukti</label>
    <input type="file" name="foto" class="form-control mb-2">

    <label>Tanggal</label>
    <input type="date" name="tanggal" class="form-control mb-2" value="{{ old('tanggal') }}">

    <label>Siswa</label>
    <select name="siswa_id" class="form-control mb-2" required>
        <option value="">-- pilih siswa --</option>
        @foreach ($siswa as $s)
            <option value="{{ $s->id }}" {{ old('siswa_id') == $s->id ? 'selected' : '' }}>
                {{ $s->nama }} - {{ $s->kelas->kelas ?? '-' }}
            </option>
        @endforeach
    </select>

    <label>Jenis Pelanggaran</label>
    <select name="jenis_id" class="form-control mb-2" required>
        <option value="">-- pilih jenis --</option>
        @foreach ($jenis as $j)
            <option value="{{ $j->id }}" {{ old('jenis_id') == $j->id ? 'selected' : '' }}>
                {{ $j->jenis }} ({{ $j->poin }} poin)
            </option>
        @endforeach
    </select>

    <label>Petugas</label>
    <select name="user_id" class="form-control mb-2">
        <option value="">-- pilih petugas (optional) --</option>
        @foreach ($user as $u)
            <option value="{{ $u->id }}" {{ old('user_id') == $u->id ? 'selected' : '' }}>
                {{ $u->nama }}
            </option>
        @endforeach
    </select>

    <button class="btn btn-primary mt-3">Simpan</button>
</form>
@endsection
