@extends('admin.layouts.admin')

@section('content')
<h3>Edit Jenis Pelanggaran</h3>

<form action="{{ url('admin/jenis/' . $jenis->id) }}" method="POST">
    @csrf @method('PUT')

    <label>Jenis Pelanggaran</label>
    <input type="text" name="jenis" value="{{ $jenis->jenis }}" class="form-control mb-2">

    <label>Keterangan</label>
    <input type="text" name="keterangan" value="{{ $jenis->keterangan }}" class="form-control mb-2">

    <label>Poin</label>
    <input type="number" name="poin" value="{{ $jenis->poin }}" class="form-control mb-2">

    <button class="btn btn-primary mt-3">Update</button>
</form>
@endsection
