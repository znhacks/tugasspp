@extends('admin.layouts.admin')

@section('content')
<h3>Jenis Pelanggaran</h3>

<a href="{{ url('admin/jenis/create') }}" class="btn btn-primary mb-3">Tambah Jenis</a>

<table class="table table-bordered">
    <tr>
        <th>Jenis</th>
        <th>Poin</th>
        <th>Aksi</th>
    </tr>

    @foreach ($data as $j)
    <tr>
        <td>{{ $j->jenis }}</td>
        <td>{{ $j->poin }}</td>
        <td>
            <a href="{{ url('admin/jenis/' . $j->id . '/edit') }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ url('admin/jenis/' . $j->id) }}" method="POST" style="display:inline">
                @csrf @method('DELETE')
                <button class="btn btn-danger btn-sm">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>
@endsection
