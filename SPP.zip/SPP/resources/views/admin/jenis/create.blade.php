@extends('admin.layouts.admin')

@section('content')
<h3>Tambah Jenis Pelanggaran</h3>

<form action="{{ url('admin/jenis') }}" method="POST">
    @csrf

    <label>Jenis Pelanggaran</label>
    <input type="text" name="jenis" class="form-control mb-2">

    <label>Keterangan</label>
    <input type="text" name="keterangan" class="form-control mb-2">

    <label>Poin</label>
    <input type="number" name="poin" class="form-control mb-2">

    <button class="btn btn-primary mt-3">Simpan</button>
</form>
@endsection
