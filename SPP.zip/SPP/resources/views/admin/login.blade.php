<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5" style="max-width:400px;">
    <h3 class="text-center mb-3">Login Admin</h3>

    <form action="{{ url('/admin/login') }}" method="POST">
        @csrf

        <label>Username</label>
        <input type="text" name="username" class="form-control mb-2" required>

        <label>Password</label>
        <input type="password" name="password" class="form-control mb-3" required>

        <button class="btn btn-primary w-100">Login</button>
    </form>

    <div class="text-center mt-3">
        <a href="/admin/register" class="btn btn-success w-100">
            Register
        </a>
    </div>

    <div class="text-center mt-2">
        <a href="/" class="btn btn-secondary w-100">
            Home
        </a>
    </div>

</div>

</body>
</html>
