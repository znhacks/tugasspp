@extends('admin.layouts.admin')

@section('content')
<h3>Tambah Kelas</h3>

<form action="{{ url('admin/kelas') }}" method="POST">
    @csrf

    <div class="mb-3">
        <label>Kelas</label>
        <input type="text" name="kelas" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Wali Kelas</label>
        <input type="text" name="walikelas" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Keterangan</label>
        <textarea name="keterangan" class="form-control"></textarea>
    </div>

    <button class="btn btn-primary">Simpan</button>
    <a href="{{ url('admin/kelas') }}" class="btn btn-secondary">Kembali</a>
</form>
@endsection
