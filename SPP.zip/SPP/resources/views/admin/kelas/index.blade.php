@extends('admin.layouts.admin')

@section('content')
<h3>Data Kelas</h3>

<a href="{{ url('admin/kelas/create') }}" class="btn btn-primary mb-3">Tambah Kelas</a>

<table class="table table-bordered">
    <tr>
        <th>Kelas</th>
        <th>Wali Kelas</th>
        <th>Aksi</th>
    </tr>

    @foreach ($data as $k)
    <tr>
        <td>{{ $k->kelas }}</td>
        <td>{{ $k->walikelas }}</td>
        <td>
            <a href="{{ url('admin/kelas/' . $k->id . '/edit') }}" class="btn btn-warning btn-sm">Edit</a>

            <form action="{{ url('admin/kelas/' . $k->id) }}" 
                  method="POST" style="display:inline;">
                @csrf @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">
                    Hapus
                </button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

@endsection
