@extends('admin.layouts.admin')

@section('content')
<h3>Edit Kelas</h3>

<form action="{{ url('admin/kelas/' . $kelas->id) }}" method="POST">
    @csrf @method('PUT')

    <label>Nama Kelas</label>
    <input type="text" name="kelas" value="{{ $kelas->kelas }}" class="form-control mb-2">

    <label>Wali Kelas</label>
    <input type="text" name="walikelas" value="{{ $kelas->walikelas }}" class="form-control mb-2">

    <label>Keterangan</label>
    <input type="text" name="keterangan" value="{{ $kelas->keterangan }}" class="form-control mb-2">

    <button class="btn btn-primary mt-3">Update</button>
</form>
@endsection
