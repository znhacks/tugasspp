@extends('admin.layouts.admin')

@section('content')
<h3>Tambah Siswa</h3>

<form action="{{ url('admin/siswa') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <label>NIS</label>
    <input type="text" name="nis" class="form-control mb-2">

    <label>Nama</label>
    <input type="text" name="nama" class="form-control mb-2">

    <label>Jenis Kelamin</label>
    <select name="kelamin" class="form-control mb-2">
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
    </select>

    <label>Agama</label>
    <input type="text" name="agama" class="form-control mb-2">

    <label>Alamat</label>
    <textarea name="alamat" class="form-control mb-2"></textarea>

    <label>Foto</label>
    <input type="file" name="foto" class="form-control mb-2">

    <label>Kelas</label>
    <select name="kelas_id" class="form-control mb-2">
        @foreach ($kelas as $k)
            <option value="{{ $k->id }}">{{ $k->kelas }}</option>
        @endforeach
    </select>

    <button class="btn btn-primary mt-3">Simpan</button>
</form>
@endsection
