@extends('admin.layouts.admin')

@section('content')
<h3>Edit Siswa</h3>

<form action="{{ url('admin/siswa/' . $siswa->id) }}" method="POST" enctype="multipart/form-data">
    @csrf @method('PUT')

    <label>NIS</label>
    <input type="text" name="nis" value="{{ $siswa->nis }}" class="form-control mb-2">

    <label>Nama</label>
    <input type="text" name="nama" value="{{ $siswa->nama }}" class="form-control mb-2">

    <label>Jenis Kelamin</label>
    <select name="kelamin" class="form-control mb-2">
        <option {{ $siswa->kelamin=='Laki-laki'?'selected':'' }}>Laki-laki</option>
        <option {{ $siswa->kelamin=='Perempuan'?'selected':'' }}>Perempuan</option>
    </select>

    <label>Agama</label>
    <input type="text" name="agama" value="{{ $siswa->agama }}" class="form-control mb-2">

    <label>Alamat</label>
    <textarea name="alamat" class="form-control mb-2">{{ $siswa->alamat }}</textarea>

    <label>Kelas</label>
    <select name="kelas_id" class="form-control mb-2">
        @foreach ($kelas as $k)
            <option value="{{ $k->id }}" {{ $siswa->kelas_id==$k->id?'selected':'' }}>
                {{ $k->kelas }}
            </option>
        @endforeach
    </select>

    <button class="btn btn-primary mt-3">Update</button>
</form>
@endsection
