@extends('admin.layouts.admin')

@section('content')
<h3>Data Siswa</h3>

<a href="{{ url('admin/siswa/create') }}" class="btn btn-primary mb-3">Tambah Siswa</a>

<table class="table table-bordered">
    <tr>
        <th>Foto</th>
        <th>NIS</th>
        <th>Nama</th>
        <th>Kelas</th>
        <th>Aksi</th>
    </tr>

    @foreach ($data as $s)
    <tr>
        <td style="width:100px">
            @if($s->foto)
                <a href="#" class="thumb" data-src="{{ asset('storage/' . $s->foto) }}" title="Klik untuk memperbesar">
                    <img src="{{ asset('storage/' . $s->foto) }}" alt="foto" class="img-thumb img-thumbnail">
                </a>
            @else
                <img src="{{ asset('images/placeholder-80.png') }}" alt="no photo" class="img-thumb img-thumbnail">
            @endif
        </td>
        <td>{{ $s->nis }}</td>
        <td>{{ $s->nama }}</td>
        <td>{{ $s->kelas->kelas ?? '-' }}</td>
        <td>
            <a href="{{ url('admin/siswa/' . $s->id . '/edit') }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ url('admin/siswa/' . $s->id) }}" method="POST" style="display:inline">
                @csrf @method('DELETE')
                <button class="btn btn-danger btn-sm">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

<!-- Image modal (Bootstrap) -->
<div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content bg-transparent border-0">
      <div class="modal-body p-0 text-center">
        <button type="button" class="btn-close position-absolute end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
        <img id="modalImage" src="" alt="preview" style="max-width:100%; max-height:80vh; object-fit:contain;">
      </div>
    </div>
  </div>
</div>

<style>
.img-thumb { width:80px; height:80px; object-fit:cover; cursor:pointer; }
</style>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    const modalEl = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const bsModal = new bootstrap.Modal(modalEl);

    document.querySelectorAll('.thumb').forEach(function(el){
        el.addEventListener('click', function(e){
            e.preventDefault();
            const src = this.getAttribute('data-src');
            modalImage.src = src;
            bsModal.show();
        });
    });

    modalEl.addEventListener('hidden.bs.modal', function () {
        modalImage.src = '';
    });
});
</script>
@endpush

@endsection
