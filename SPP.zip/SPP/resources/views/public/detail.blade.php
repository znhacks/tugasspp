<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Detail Pelanggaran Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">

<div class="max-w-4xl mx-auto mt-12 px-4">

    <!--header-->
    <div class="text-center mb-10">
        <h1 class="text-3xl font-bold text-gray-800">{{ $siswa->nama }}</h1>
        <p class="text-gray-500">Kelas: {{ $siswa->kelas->kelas }}</p>
    </div>

    <!--card-->
    <div class="bg-white shadow-xl rounded-2xl p-6 border border-gray-200">

        <h2 class="text-xl font-bold mb-4 text-gray-800">Riwayat Pelanggaran</h2>

        @if(count($pelanggaran) == 0)
            <p class="text-gray-500">Tidak ada pelanggaran.</p>

        @else
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-100 border-b">
                        <th class="px-4 py-2 font-medium text-gray-700">Jenis</th>
                        <th class="px-4 py-2 font-medium text-gray-700">Tanggal</th>
                        <th class="px-4 py-2 font-medium text-gray-700">Foto</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-gray-200">
                    @foreach($pelanggaran as $p)
                    <tr class="hover:bg-gray-50">
                        <td class="px-4 py-3">{{ $p->jenis->jenis }}</td>
                        <td class="px-4 py-3">{{ $p->tanggal }}</td>

                        <!--tamnel-->
                        <td class="px-4 py-3">
                            @if($p->foto)
                                <img src="{{ asset('storage/' . $p->foto) }}"
                                     class="w-20 h-20 object-cover rounded shadow cursor-pointer"
                                     onclick="showImage('{{ asset('storage/' . $p->foto) }}')">
                            @else
                                <span class="text-gray-400 text-sm">Tidak ada foto</span>
                            @endif
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        @endif
    </div>

    <!--buttonygy-->
    <div class="text-center mt-6">
        <a href="/" class="px-6 py-2 bg-blue-600 text-white rounded-lg shadow hover:bg-blue-700">
            Kembali
        </a>
    </div>

</div>


<!--zoom-->
<div id="imageModal"
     class="fixed inset-0 bg-black bg-opacity-70 hidden items-center justify-center p-4"
     onclick="this.classList.add('hidden')">

    <img id="modalImage"
         class="max-w-full max-h-full rounded-lg shadow-xl">
</div>

<script>
    function showImage(src) {
        document.getElementById('modalImage').src = src;
        document.getElementById('imageModal').classList.remove('hidden');
    }
</script>

</body>
</html>
