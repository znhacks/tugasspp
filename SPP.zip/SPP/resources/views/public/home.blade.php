
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pelanggaran Siswa</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
<div class="max-w-6xl mx-auto mt-12 px-4">

    <div class="text-center mb-10">
        <h1 class="text-4xl font-bold text-gray-800">Daftar Pelanggaran Siswa</h1>
        <p class="text-gray-500 mt-2">Rekap pelanggaran yang telah tercatat dalam sistem</p>
    </div>

    <div class="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100">
        <table class="w-full text-left">
            <thead class="bg-gray-100 border-b">
                <tr class="text-gray-700">
                    <th class="px-6 py-3 font-semibold">Nama</th>
                    <th class="px-6 py-3 font-semibold">Jenis Pelanggaran</th>
                    <th class="px-6 py-3 font-semibold">Tanggal</th>
                    <th class="px-6 py-3 font-semibold">Detail</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-200 bg-white">
                @forelse($pelanggaran as $p)
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4 text-gray-800">{{ optional($p->siswa)->nama ?? '-' }}</td>
                    <td class="px-6 py-4">{{ optional($p->jenis)->jenis ?? '-' }}</td>
                    <td class="px-6 py-4">{{ $p->tanggal ?? '-' }}</td>
                    <td class="px-6 py-4">
                        @if(optional($p->siswa)->id)
                        <a href="{{ url('/siswa/' . $p->siswa->id) }}"
                           class="text-blue-600 font-medium hover:text-blue-700 hover:underline">
                           Lihat
                        </a>
                        @else
                        -
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="4" class="px-6 py-6 text-center text-gray-500">Belum ada data pelanggaran.</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        {{ $pelanggaran->links() }}
    </div>

    <div class="text-center mt-8">
        <a href="/admin/login"
           class="inline-block bg-blue-600 text-white px-6 py-2.5 rounded-lg shadow hover:bg-blue-700 transition">
            Login Admin
        </a>
    </div>

</div>
</body>
</html>
