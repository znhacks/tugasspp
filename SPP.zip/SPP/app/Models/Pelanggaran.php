<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pelanggaran extends Model
{
    protected $table = 'pelanggaran';

    protected $fillable = [
        'foto',
        'tanggal',
        'jenis_id',
        'siswa_id',
        'user_id',
    ];

    public function jenis()
    {
        return $this->belongsTo(Jenis::class);
    }

    public function siswa()
    {
        return $this->belongsTo(Siswa::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
