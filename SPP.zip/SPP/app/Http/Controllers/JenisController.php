<?php

namespace App\Http\Controllers;

use App\Models\Jenis;
use Illuminate\Http\Request;

class JenisController extends Controller
{
    public function index()
    {
        $data = Jenis::all();
        return view('admin.jenis.index', compact('data'));
    }

    public function create()
    {
        return view('admin.jenis.create');
    }

    public function store(Request $request)
    {
        Jenis::create($request->all());
        return redirect('admin/jenis');
    }

    public function edit($id)
    {
        $jenis = Jenis::findOrFail($id);
        return view('admin.jenis.edit', compact('jenis'));
    }

    public function update(Request $request, $id)
    {
        Jenis::findOrFail($id)->update($request->all());
        return redirect('admin/jenis');
    }

    public function destroy($id)
    {
        Jenis::destroy($id);
        return redirect('admin/jenis');
    }
}
