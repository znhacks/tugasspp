<?php

namespace App\Http\Controllers;

use App\Models\Siswa;
use App\Models\Kelas;
use Illuminate\Http\Request;

class SiswaController extends Controller
{
    public function index()
    {
        $data = Siswa::with('kelas')->get();
        return view('admin.siswa.index', compact('data'));
    }

    public function create()
    {
        $kelas = Kelas::all();
        return view('admin.siswa.create', compact('kelas'));
    }

    public function store(Request $request)
    {
        $foto = null;
        if ($request->hasFile('foto')) {
            $foto = $request->file('foto')->store('foto', 'public');
        }

        Siswa::create([
            'nis' => $request->nis,
            'nama' => $request->nama,
            'kelamin' => $request->kelamin,
            'agama' => $request->agama,
            'alamat' => $request->alamat,
            'foto' => $foto,
            'kelas_id' => $request->kelas_id,
        ]);

        return redirect('admin/siswa');
    }

    public function edit($id)
    {
        $siswa = Siswa::findOrFail($id);
        $kelas = Kelas::all();
        return view('admin.siswa.edit', compact('siswa', 'kelas'));
    }

    public function update(Request $request, $id)
    {
        $siswa = Siswa::findOrFail($id);

        if ($request->hasFile('foto')) {
            $siswa->foto = $request->file('foto')->store('foto', 'public');
        }

        $siswa->update([
            'nis' => $request->nis,
            'nama' => $request->nama,
            'kelamin' => $request->kelamin,
            'agama' => $request->agama,
            'alamat' => $request->alamat,
            'kelas_id' => $request->kelas_id,
        ]);

        return redirect('admin/siswa');
    }

    public function destroy($id)
    {
        Siswa::destroy($id);
        return redirect('admin/siswa');
    }
}
