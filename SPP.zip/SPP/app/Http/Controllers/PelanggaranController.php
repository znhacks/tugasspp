<?php

namespace App\Http\Controllers;

use App\Models\Pelanggaran;
use App\Models\Siswa;
use App\Models\Jenis;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class PelanggaranController extends Controller
{
    public function index()
    {
        $data = Pelanggaran::with('siswa', 'jenis', 'user')->orderBy('id', 'desc')->get();
        return view('admin.pelanggaran.index', compact('data'));
    }

    public function create()
    {
        return view('admin.pelanggaran.create', [
            'siswa' => Siswa::all(),
            'jenis' => Jenis::all(),
            'user'  => User::all(),
        ]);
    }

    public function store(Request $request)
    {
        // normalize empty string -> null so 'nullable|exists' won't reject it
        if ($request->input('user_id') === '') {
            $request->merge(['user_id' => null]);
        }

        // resolve actual users table name (handles tables named 'user' or 'users')
        $userTable = (new User())->getTable();

        $validated = $request->validate([
            'tanggal'   => 'required|date',
            'jenis_id'  => 'required|exists:jenis,id',
            'siswa_id'  => 'required|exists:siswa,id',
            'user_id'   => 'nullable|integer|exists:' . $userTable . ',id',
            'foto'      => 'nullable|image|max:2048',
        ]);

        Log::info('Pelanggaran store called', ['request_keys' => array_keys($request->all())]);

        try {
            DB::beginTransaction();

            $fotoPath = null;
            if ($request->hasFile('foto')) {
                $fotoPath = $request->file('foto')->store('foto', 'public');
                Log::info('Foto stored', ['path' => $fotoPath]);
            }

            $pelanggaran = Pelanggaran::create([
                'foto'     => $fotoPath,
                'tanggal'  => $validated['tanggal'],
                'jenis_id' => $validated['jenis_id'],
                'siswa_id' => $validated['siswa_id'],
                'user_id'  => $request->input('user_id') ?? auth()->id(),
            ]);

            DB::commit();

            Log::info('Pelanggaran created', ['id' => $pelanggaran->id]);

            return redirect('/admin/pelanggaran')->with('success', 'Pelanggaran berhasil ditambahkan.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Pelanggaran store failed', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);

            return back()->withInput()->withErrors(['msg' => 'Gagal menyimpan data: ' . $e->getMessage()]);
        }
    }

    public function publicIndex()
    {
        // tampilkan semua siswa + pelanggarannya di halaman publik
        $pelanggaran = Pelanggaran::with([
            'siswa:id,nama',   // load only needed columns
            'jenis:id,jenis'
        ])
        ->orderBy('tanggal', 'desc')
        ->paginate(25); // use paginate to avoid memory issues

        return view('public.home', compact('pelanggaran'));
    }

    public function publicDetail($id)
    {
        // detail pelanggaran per siswa
        $siswa = Siswa::with('kelas')->findOrFail($id);
        $pelanggaran = Pelanggaran::with('jenis')
                        ->where('siswa_id', $id)->get();

        return view('public.detail', compact('siswa', 'pelanggaran'));
    }

    public function edit(Pelanggaran $pelanggaran)
    {
        return view('admin.pelanggaran.edit', [
            'pelanggaran' => $pelanggaran,
            'siswa' => Siswa::orderBy('nama')->get(),
            'jenis' => Jenis::orderBy('jenis')->get(),
            'user'  => User::orderBy('nama')->get(),
        ]);
    }

    public function update(Request $request, Pelanggaran $pelanggaran)
    {
        if ($request->input('user_id') === '') {
            $request->merge(['user_id' => null]);
        }

        $userTable = (new User())->getTable();

        $validated = $request->validate([
            'tanggal'   => 'required|date',
            'jenis_id'  => 'required|exists:jenis,id',
            'siswa_id'  => 'required|exists:siswa,id',
            'user_id'   => 'nullable|integer|exists:' . $userTable . ',id',
            'foto'      => 'nullable|image|max:2048',
        ]);

        DB::beginTransaction();
        try {
            if ($request->hasFile('foto')) {
                // delete old file if exists
                if ($pelanggaran->foto) {
                    Storage::disk('public')->delete($pelanggaran->foto);
                }
                $pelanggaran->foto = $request->file('foto')->store('foto', 'public');
            }

            $pelanggaran->tanggal = $validated['tanggal'];
            $pelanggaran->jenis_id = $validated['jenis_id'];
            $pelanggaran->siswa_id = $validated['siswa_id'];
            $pelanggaran->user_id  = $validated['user_id'] ?? $pelanggaran->user_id ?? auth()->id();

            $pelanggaran->save();

            DB::commit();

            return redirect('/admin/pelanggaran')->with('success', 'Pelanggaran updated.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Pelanggaran update failed', ['error' => $e->getMessage()]);
            return back()->withInput()->withErrors(['msg' => 'Gagal memperbarui: '.$e->getMessage()]);
        }
    }

    public function destroy(Pelanggaran $pelanggaran)
    {
        try {
            DB::beginTransaction();

            if ($pelanggaran->foto) {
                Storage::disk('public')->delete($pelanggaran->foto);
                Storage::disk('public')->delete('foto/thumbs/' . basename($pelanggaran->foto));
            }

            $pelanggaran->delete();

            DB::commit();

            return redirect('/admin/pelanggaran')->with('success', 'Pelanggaran dihapus.');
        } catch (\Throwable $e) {
            DB::rollBack();
            Log::error('Pelanggaran destroy failed', ['error' => $e->getMessage()]);
            return back()->withErrors(['msg' => 'Gagal menghapus: ' . $e->getMessage()]);
        }
    }
}
