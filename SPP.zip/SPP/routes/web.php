<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\JenisController;
use App\Http\Controllers\KelasController;
use App\Http\Controllers\PelanggaranController;

/*
|--------------------------------------------------------------------------
| PUBLIC PAGE
|--------------------------------------------------------------------------
*/

// Home publik
Route::get('/', [PelanggaranController::class, 'publicIndex'])->name('public.home');

// Detail per siswa
Route::get('/siswa/{id}', [PelanggaranController::class, 'publicDetail'])->name('public.detail');



/*
|--------------------------------------------------------------------------
| GUEST PAGES (LOGIN & REGISTER)
|--------------------------------------------------------------------------
*/
Route::middleware('guest')->group(function () {

    Route::get('/admin/login', [AuthController::class, 'loginPage'])->name('login');
    Route::post('/admin/login', [AuthController::class, 'login']);

    Route::get('/admin/register', [AuthController::class, 'registerPage'])->name('register');
    Route::post('/admin/register', [AuthController::class, 'register']);
});



/*
|--------------------------------------------------------------------------
| ADMIN AREA (AUTH)
|--------------------------------------------------------------------------
*/
Route::middleware('auth')->group(function () {

    // existing route
    Route::get('/admin', [PelanggaranController::class, 'index'])->name('admin.dashboard');

    // add this alias so /admin/dashboard works too
    Route::get('/admin/dashboard', [PelanggaranController::class, 'index']);


    Route::resource('/admin/siswa', SiswaController::class);
    Route::resource('/admin/kelas', KelasController::class);
    Route::resource('/admin/jenis', JenisController::class);
    Route::resource('/admin/pelanggaran', PelanggaranController::class);

    Route::post('/admin/logout', [AuthController::class, 'logout'])->name('logout');
});
