<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('jenis', function (Blueprint $table) {
            $table->id(); // int(10) AUTO_INCREMENT
            $table->string('jenis', 255);
            $table->string('keterangan', 255)->nullable();
            $table->integer('poin');
        });

        Schema::create('kelas', function (Blueprint $table) {
            $table->id(); // int(11)
            $table->string('kelas', 20);
            $table->string('walikelas', 55);
            $table->string('keterangan', 255)->nullable();
        });

        Schema::create('siswa', function (Blueprint $table) {
            $table->id(); // int(10)
            $table->string('nis', 15);
            $table->string('nama', 55);
            $table->string('kelamin', 20);
            $table->string('agama', 20);
            $table->string('alamat', 255)->nullable();
            $table->string('foto', 255);
        });

        Schema::create('user', function (Blueprint $table) {
            $table->id(); // int(11)
            $table->string('username', 5);
            $table->string('password', 255);
            $table->string('nama', 255);
            $table->string('kelamin', 20);
            $table->string('alamat', 255)->nullable();
            $table->string('level', 20);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('siswa');
        Schema::dropIfExists('kelas');
        Schema::dropIfExists('jenis');
    }
};
